data class ConversionResponse(
    val result: Double,   // Assuming the API returns a result field with the conversion rate
    val date: String      // Assuming there's a date field (adjust based on the actual API response)
)
