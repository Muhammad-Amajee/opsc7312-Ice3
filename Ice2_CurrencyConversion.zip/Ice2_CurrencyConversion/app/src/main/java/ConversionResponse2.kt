data class ConversionResponse(
    val result: Double,
    val date: String,
    val base: String,     // The base currency (e.g., "USD")
    val target: String    // The target currency (e.g., "EUR")
)
