import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface CurrencyApi {
    @GET("convert") // Assuming the endpoint for conversion is 'convert'
    fun getConversionRate(
        @Query("from") from: String, // Currency to convert from
        @Query("to") to: String,     // Currency to convert to
        @Query("amount") amount: Double  // Amount to convert
    ): Call<ConversionResponse>
}
