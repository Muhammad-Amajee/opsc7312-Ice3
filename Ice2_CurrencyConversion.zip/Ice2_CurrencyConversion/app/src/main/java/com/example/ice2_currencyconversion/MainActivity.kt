package com.example.ice2_currencyconversion

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fromCurrencyInput: EditText = findViewById(R.id.fromCurrencyInput)
        val toCurrencyInput: EditText = findViewById(R.id.toCurrencyInput)
        val amountInput: EditText = findViewById(R.id.amountInput)
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        val convertButton: Button = findViewById(R.id.convertButton)

        convertButton.setOnClickListener {
            val fromCurrency = fromCurrencyInput.text.toString()
            val toCurrency = toCurrencyInput.text.toString()
            val amount = amountInput.text.toString().toDoubleOrNull() ?: 0.0

            if (fromCurrency.isNotEmpty() && toCurrency.isNotEmpty() && amount > 0.0) {
                getConversionRate(fromCurrency, toCurrency, amount, resultTextView)
            }
        }
    }

    // API call function
    private fun getConversionRate(from: String, to: String, amount: Double, resultTextView: TextView) {
        val api = RetrofitClient.instance.create(CurrencyApi::class.java)

        api.getConversionRate(from, to, amount).enqueue(object : Callback<ConversionResponse> {
            override fun onResponse(call: Call<ConversionResponse>, response: Response<ConversionResponse>) {
                if (response.isSuccessful) {
                    val conversionResult = response.body()?.result
                    resultTextView.text = "Converted Amount: $conversionResult"
                } else {
                    resultTextView.text = "Failed to retrieve conversion rate."
                }
            }

            override fun onFailure(call: Call<ConversionResponse>, t: Throwable) {
                resultTextView.text = "Error: ${t.message}"
            }
        })
    }
}


    val api = RetrofitClient.instance.create(CurrencyApi::class.java)
    api.getConversionRate("USD", "EUR", 100.0).enqueue(object : retrofit2.Callback<ConversionResponse> {
        override fun onResponse(call: retrofit2.Call<ConversionResponse>, response: retrofit2.Response<ConversionResponse>) {
            if (response.isSuccessful) {
                val result = response.body()?.result
            }
        }

        override fun onFailure(call: retrofit2.Call<ConversionResponse>, t: Throwable) {
        }
    })

}